import sys
from flask import Flask, render_template, request


CURRENT_FILE = __file__.replace('\\', '/')
FRONTEND_FOLDER = CURRENT_FILE.rsplit('/', 1)[0]
PROJECT_FOLDER = CURRENT_FILE.rsplit('/', 2)[0]
BACKEND_FOLDER = PROJECT_FOLDER + '/backend'

if BACKEND_FOLDER not in sys.path:
    sys.path.insert(0, BACKEND_FOLDER)

from best_model import predict_email


app = Flask(
    __name__,
    template_folder=FRONTEND_FOLDER,
    static_folder=FRONTEND_FOLDER,
    static_url_path=''
)


@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    sender = ''
    subject = ''
    body = ''

    if request.method == 'POST':
        sender = request.form.get('sender', '').strip()
        subject = request.form.get('subject', '').strip()
        body = request.form.get('body', '').strip()

        prediction = predict_email(sender, subject, body, '')
        result = 'Phishing' if prediction == 1 else 'Legit'

    return render_template(
        'index.html',
        result=result,
        sender=sender,
        subject=subject,
        body=body
    )


if __name__ == '__main__':
    app.run(debug=True)