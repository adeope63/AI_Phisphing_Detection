def combine_text_columns(dataframe):
    """
    Combine sender, subject, body, and urls into one text field.
    """
    df = dataframe.copy()

    combined_text = (
        df['sender'].fillna('').astype(str) + ' ' +
        df['subject'].fillna('').astype(str) + ' ' +
        df['body'].fillna('').astype(str) + ' ' +
        df['urls'].fillna('').astype(str)
    )

    return combined_text