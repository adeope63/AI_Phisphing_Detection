import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report

from features import combine_text_columns


CURRENT_FILE = __file__.replace('\\', '/')
BACKEND_FOLDER = CURRENT_FILE.rsplit('/', 1)[0]
DATASET_FILE = BACKEND_FOLDER + '/CEAS_08.csv'
MODEL_FILE = BACKEND_FOLDER + '/output/best_phishing_model.pkl'


# Load saved bundle
saved_bundle = joblib.load(MODEL_FILE)
vectorizer = saved_bundle['vectorizer']
model = saved_bundle['model']


def predict_email(sender, subject, body, urls=''):
    """
    Predict one email using the saved best model.
    """
    sample = pd.DataFrame([
        {
            'sender': str(sender),
            'subject': str(subject),
            'body': str(body),
            'urls': str(urls)
        }
    ])

    sample_text = combine_text_columns(sample)
    sample_vector = vectorizer.transform(sample_text)
    prediction = model.predict(sample_vector)[0]
    return prediction


# Load dataset again to validate model performance
data = pd.read_csv(DATASET_FILE)
data['label'] = data['label'].astype(int)
data['sender'] = data['sender'].fillna('').astype(str)
data['subject'] = data['subject'].fillna('').astype(str)
data['body'] = data['body'].fillna('').astype(str)
data['urls'] = data['urls'].fillna('').astype(str)

x = data[['sender', 'subject', 'body', 'urls']]
y = data['label']

x_train, x_test, y_train, y_test = train_test_split(
    x,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# Convert to text, then vectorize
train_text = combine_text_columns(x_train)
test_text = combine_text_columns(x_test)

x_train_vectors = vectorizer.transform(train_text)
x_test_vectors = vectorizer.transform(test_text)

# Predict
train_predictions = model.predict(x_train_vectors)
test_predictions = model.predict(x_test_vectors)

# Training metrics
train_accuracy = accuracy_score(y_train, train_predictions)
train_precision = precision_score(y_train, train_predictions, pos_label=1)
train_recall = recall_score(y_train, train_predictions, pos_label=1)
train_f1 = f1_score(y_train, train_predictions, pos_label=1)

# Testing metrics
test_accuracy = accuracy_score(y_test, test_predictions)
test_precision = precision_score(y_test, test_predictions, pos_label=1)
test_recall = recall_score(y_test, test_predictions, pos_label=1)
test_f1 = f1_score(y_test, test_predictions, pos_label=1)

print('\nBest Model Training Metrics')
print(f'Accuracy : {train_accuracy:.4f}')
print(f'Precision: {train_precision:.4f}')
print(f'Recall   : {train_recall:.4f}')
print(f'F1-Score : {train_f1:.4f}')

print('\nBest Model Testing Metrics')
print(f'Accuracy : {test_accuracy:.4f}')
print(f'Precision: {test_precision:.4f}')
print(f'Recall   : {test_recall:.4f}')
print(f'F1-Score : {test_f1:.4f}')

print('\nAccuracy Gap:', round(train_accuracy - test_accuracy, 4))
print('F1 Gap      :', round(train_f1 - test_f1, 4))

print('\nTesting Classification Report')
print(classification_report(y_test, test_predictions))