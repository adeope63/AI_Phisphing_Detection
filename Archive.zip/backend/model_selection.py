import pandas as pd
import matplotlib.pyplot as plt
import joblib

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC

from features import combine_text_columns


CURRENT_FILE = __file__.replace('\\', '/')
BACKEND_FOLDER = CURRENT_FILE.rsplit('/', 1)[0]
DATASET_FILE = BACKEND_FOLDER + '/CEAS_08.csv'
OUTPUT_FOLDER = BACKEND_FOLDER + '/output'


# Load dataset
data = pd.read_csv(DATASET_FILE)

# Clean fields
data['label'] = data['label'].astype(int)
data['sender'] = data['sender'].fillna('').astype(str)
data['subject'] = data['subject'].fillna('').astype(str)
data['body'] = data['body'].fillna('').astype(str)
data['urls'] = data['urls'].fillna('').astype(str)

# Keep only useful columns
x = data[['sender', 'subject', 'body', 'urls']]
y = data['label']

# Split data into test and train
x_train, x_test, y_train, y_test = train_test_split(
    x,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# Combine text
train_text = combine_text_columns(x_train)
test_text = combine_text_columns(x_test)

# Vectorize text once
vectorizer = TfidfVectorizer(
    lowercase=True,
    stop_words='english',
    ngram_range=(1, 2),
    max_features=5000
)

x_train_vectors = vectorizer.fit_transform(train_text)
x_test_vectors = vectorizer.transform(test_text)

# Models
models = {
    'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
    'Random Forest': RandomForestClassifier(
        n_estimators=150,
        max_depth=20,
        random_state=42,
        n_jobs=-1
    ),
    'Linear SVM': LinearSVC(random_state=42)
}

results = []
best_model = None
best_model_name = ''
best_predictions = None
best_test_f1 = -1

for model_name, model in models.items():
    # Train model
    model.fit(x_train_vectors, y_train)

    # Predict on train and test
    train_predictions = model.predict(x_train_vectors)
    test_predictions = model.predict(x_test_vectors)

    # Training metrics
    train_accuracy = accuracy_score(y_train, train_predictions)
    train_precision = precision_score(y_train, train_predictions, pos_label=1)
    train_recall = recall_score(y_train, train_predictions, pos_label=1)
    train_f1 = f1_score(y_train, train_predictions, pos_label=1)

    # Testing metrics
    test_accuracy = accuracy_score(y_test, test_predictions)
    test_precision = precision_score(y_test, test_predictions, pos_label=1)
    test_recall = recall_score(y_test, test_predictions, pos_label=1)
    test_f1 = f1_score(y_test, test_predictions, pos_label=1)

    print(f'\nResults for {model_name}')
    print('Training Metrics')
    print(f'Accuracy : {train_accuracy:.4f}')
    print(f'Precision: {train_precision:.4f}')
    print(f'Recall   : {train_recall:.4f}')
    print(f'F1-Score : {train_f1:.4f}')

    print('\nTesting Metrics')
    print(f'Accuracy : {test_accuracy:.4f}')
    print(f'Precision: {test_precision:.4f}')
    print(f'Recall   : {test_recall:.4f}')
    print(f'F1-Score : {test_f1:.4f}')

    print('\nTesting Classification Report')
    print(classification_report(y_test, test_predictions))

    results.append({
        'model': model_name,
        'train_accuracy': train_accuracy,
        'train_precision': train_precision,
        'train_recall': train_recall,
        'train_f1_score': train_f1,
        'test_accuracy': test_accuracy,
        'test_precision': test_precision,
        'test_recall': test_recall,
        'test_f1_score': test_f1,
        'accuracy_gap': train_accuracy - test_accuracy,
        'f1_gap': train_f1 - test_f1
    })

    # Keep best model based on test F1-score
    if test_f1 > best_test_f1:
        best_test_f1 = test_f1
        best_model = model
        best_model_name = model_name
        best_predictions = test_predictions

# Save results
results_df = pd.DataFrame(results)
results_df = results_df.sort_values(by='test_f1_score', ascending=False).reset_index(drop=True)

print('\nModel Comparison Table')
print(results_df)

results_df.to_csv(OUTPUT_FOLDER + '/model_results.csv', index=False)

# Smaller file focused on overfitting check
overfitting_df = results_df[
    ['model', 'train_accuracy', 'test_accuracy', 'accuracy_gap', 'train_f1_score', 'test_f1_score', 'f1_gap']
]
overfitting_df.to_csv(OUTPUT_FOLDER + '/overfitting_summary.csv', index=False)

# Save the best model and vectorizer together
best_bundle = {
    'model_name': best_model_name,
    'vectorizer': vectorizer,
    'model': best_model
}
joblib.dump(best_bundle, OUTPUT_FOLDER + '/best_phishing_model.pkl')

print('\nBest Model Selected:', best_model_name)
print('Best model saved to output folder.')

# Model comparison chart using test scores
x_positions = range(len(results_df))
width = 0.2

plt.figure(figsize=(11, 6))
plt.bar([x - 1.5 * width for x in x_positions], results_df['test_accuracy'], width=width, label='Test Accuracy')
plt.bar([x - 0.5 * width for x in x_positions], results_df['test_precision'], width=width, label='Test Precision')
plt.bar([x + 0.5 * width for x in x_positions], results_df['test_recall'], width=width, label='Test Recall')
plt.bar([x + 1.5 * width for x in x_positions], results_df['test_f1_score'], width=width, label='Test F1-Score')

plt.xticks(list(x_positions), results_df['model'])
plt.xlabel('Models')
plt.ylabel('Score')
plt.ylim(0, 1.05)
plt.title('Model Comparison Bar Chart')
plt.legend()
plt.tight_layout()
plt.savefig(OUTPUT_FOLDER + '/model_comparison.png')
plt.close()

# Confusion matrix for best model
matrix = confusion_matrix(y_test, best_predictions, labels=[0, 1])
display = ConfusionMatrixDisplay(confusion_matrix=matrix, display_labels=['Legit', 'Phishing'])
display.plot()
plt.title(f'Confusion Matrix - {best_model_name}')
plt.tight_layout()
plt.savefig(OUTPUT_FOLDER + '/best_model_confusion_matrix.png')
plt.close()

print('\nFiles saved in output folder:')
print('- best_phishing_model.pkl')
print('- model_results.csv')
print('- overfitting_summary.csv')
print('- model_comparison.png')
print('- best_model_confusion_matrix.png')
print('\nTo check overfitting, compare:')
print('- train_accuracy vs test_accuracy')
print('- train_f1_score vs test_f1_score')
print('Smaller gaps usually mean less overfitting.')